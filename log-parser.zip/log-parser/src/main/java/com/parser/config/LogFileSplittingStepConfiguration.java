package com.parser.config;

import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.step.tasklet.SystemCommandTasklet;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LogFileSplittingStepConfiguration {

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    // Step 1 Beans
    @Bean
    @StepScope
    public SystemCommandTasklet fileSplittingTasklet(@Value("#{jobParameters['accesslog']}")String inputFile) throws Exception {

        SystemCommandTasklet tasklet = new SystemCommandTasklet();

        tasklet.setCommand("split -a 5 -l 10000 ../access.log");
        tasklet.setTimeout(60000l);
        tasklet.setWorkingDirectory("C:\\Users\\Tran\\Desktop\\New");
        tasklet.afterPropertiesSet();

        return tasklet;
    }

    @Bean("fileSplittingStep")
    public Step fileSplittingStep(Tasklet fileSplittingTasklet) throws Exception {
        return stepBuilderFactory.get("fileSplittingStep")
                .tasklet(fileSplittingTasklet)
                .build();
    }
}
