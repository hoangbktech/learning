package com.parser;

public enum Parameter {
	accesslog, startDate, duration, threshold, stagingDirectory
}