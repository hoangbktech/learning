package com.parser.dto;

public enum JobParameter {
	fileName, fromDate, tillDate, threshold, stagingDirectory
}