package com.parser.listener;

import static org.springframework.batch.core.BatchStatus.*;

import com.parser.utils.Constants;
import org.apache.commons.io.FileUtils;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;

@Slf4j
@Component
public class JobCompletionListener extends JobExecutionListenerSupport {

	private long startTime;

	@Override
	public void beforeJob(JobExecution jobExecution) {
		startTime = System.currentTimeMillis();
	}


	@Override
	public void afterJob(JobExecution jobExecution) {
		if (COMPLETED == jobExecution.getStatus()) {
			log.info("!!! JOB FINISHED : {}ms!", System.currentTimeMillis() - startTime);
			File splitDescFolder = new File(Constants.FILE_SPLIT_DIRECTORY);
			if (splitDescFolder.exists()) {
				try {
					FileUtils.deleteDirectory(splitDescFolder);
				} catch (IOException e) {
					log.error("Failed to remove all files generated during splitting step");
				}

			}
		} else if (FAILED == jobExecution.getStatus()) {
			log.error("!!! JOB FAILED!");
		}
	}
}