package com.parser.writer;

import com.parser.entity.RequestLog;
import com.parser.repository.RequestLogRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public class RequestLogWriter extends JpaItemWriter<RequestLog> {

    @Autowired
    private RequestLogRepository requestLogRepo;

    @Override
    public synchronized void write(List<? extends RequestLog> items) {

        Map<String, List<RequestLog>> requestsMap = items.stream().collect(Collectors.groupingBy(RequestLog::getIpAddr));

        requestsMap.forEach((k,v)->System.out.println("Item : " + k + " Count : " + v.size()));
    }

}
