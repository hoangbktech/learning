package com.parser.config;

import java.util.Date;

import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.support.DefaultConversionService;

import com.parser.converter.StringToDateConverter;
import com.parser.converter.StringToDurationConverter;
import com.parser.dto.Duration;
import com.parser.factory.DailyDurationFactory;
import com.parser.factory.DurationPeriodFactory;
import com.parser.factory.HourlyDurationFactory;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Profile("dev")
@Configuration
@EntityScan(basePackages = {"com.parser.entity"})
@EnableJpaRepositories(basePackages = {"com.parser.repository"})
public class ApplicationConfiguration {
	
	@Bean
	public ConversionService conversionService() {
		DefaultConversionService service = new DefaultConversionService();
		service.addConverter(new StringToDateConverter());
		service.addConverter(new StringToDurationConverter());
		return service;
	}

	@Bean
	public ResourcelessTransactionManager resourcelessTransactionManager() {
		return new ResourcelessTransactionManager();
	}

	@Bean
	public JobRepository jobRepository() throws Exception {
		return new MapJobRepositoryFactoryBean(resourcelessTransactionManager()).getObject();
	}
	
	@Bean
	public DurationPeriodFactory durationPeriodFactory(@Value("${duration}") Duration duration, @Value("${startDate}") Date date) {
		switch (duration) {
			case HOURLY:
				return new HourlyDurationFactory(date);
			case DAILY:
				return new DailyDurationFactory(date);
			default:
				throw new IllegalArgumentException("unsupported duration");
		}
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}