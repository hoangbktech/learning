package com.parser.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.parser.listener.JobCompletionListener;
import com.parser.validator.InputJobParametersValidator;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import javax.sql.DataSource;

@Configuration
public class JobConfiguration {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private JobCompletionListener jobCompletionListener;
	
	@Autowired
	private InputJobParametersValidator inputJobParametersValidator;

	@Autowired
	@Qualifier("masterStep")
	private Step masterStep;

	@Autowired
	@Qualifier("importLogFileStep")
	private Step slaveStep;

	@Autowired
	@Qualifier("banIpItemStep")
	private Step banIpItemStep;

	@Autowired
	@Qualifier("fileSplittingStep")
	private Step fileSplittingStep;

	@Autowired
	private DataSource dataSource;

	@Bean
	public Job processLogFileJob() {
		return jobBuilderFactory.get("processLogFileJob")
				.incrementer(new RunIdIncrementer())
				.listener(jobCompletionListener)
				.validator(inputJobParametersValidator)
				.flow(fileSplittingStep)
				.next(masterStep)
//				.next(banIpItemStep)
				.end()
				.build();
	}

//	@Bean
//	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
//		//JpaVendorAdapteradapter can be autowired as well if it's configured in application properties.
//		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
//		vendorAdapter.setGenerateDdl(false);
//
//		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
//		factory.setJpaVendorAdapter(vendorAdapter);
//		//Add package to scan for entities.
//		factory.setPackagesToScan("com.parser.entity");
//		factory.setDataSource(dataSource);
//		return factory;
//	}
}