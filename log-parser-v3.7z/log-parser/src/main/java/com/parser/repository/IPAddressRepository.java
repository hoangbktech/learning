package com.parser.repository;

import com.parser.entity.IPAddress;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IPAddressRepository extends CrudRepository<IPAddress,Integer> {
    IPAddress findByIp(String ip);
}
