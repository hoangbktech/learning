package com.parser.processor;

import static org.apache.commons.lang3.time.DateUtils.parseDate;

import com.parser.entity.IPAddress;
import com.parser.entity.RequestLog;
import com.parser.repository.IPAddressRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.parser.dto.LogItemDto;
import com.parser.entity.LogItemEntity;

import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Component
@StepScope
public class ImportLogItemProcessor implements ItemProcessor<LogItemDto, RequestLog> {

	private static final String DATE_PATTERN = "yyyy-MM-dd hh:mm:ss.SSS";
	private final Map<String, Integer> ipMap = new HashMap<>();

	@Value("#{jobParameters['threshold']}")
	private int threshold;

	@Value("#{jobParameters['fromDate']}")
	private Date fromDate;

	@Value("#{jobParameters['tillDate']}")
	private Date tillDate;

	@Autowired
	private IPAddressRepository ipAddressRepo;

	private Long jobId;
	
	@BeforeStep
	public void setInterStepData(StepExecution stepExecution) {
	    JobExecution jobExecution = stepExecution.getJobExecution();
	    this.jobId = jobExecution.getJobId();
	}
	
	@Override
	public synchronized RequestLog process(LogItemDto itemDto) throws Exception {

		String ip = itemDto.getIp();

		log.info("processing ip : {}", ip);
		ipMap.put(ip, ipMap.get(ip) == null ? 1 : ipMap.get(ip) + 1);
		boolean isBanned = isBanned(ipMap.get(ip), threshold, parseDate(itemDto.getDate(), DATE_PATTERN), fromDate, tillDate);


		RequestLog entity = new RequestLog();
		entity.setJobId(jobId);
		entity.setCreatedAt(parseDate(itemDto.getDate(), DATE_PATTERN));
		entity.setIpAddr(ip);
		entity.setIp(new IPAddress());
		entity.setRequest(itemDto.getRequest());
		entity.setStatus(itemDto.getStatus());
		entity.setUserAgent(itemDto.getUserAgent());

		entity.setBlocked(isBanned);

		return entity;
	}

	private boolean isBanned(int count, int threshold, Date requestDate, Date fromDate, Date tillDate) {
		return count > threshold && requestDate.compareTo(fromDate) >= 0 && requestDate.compareTo(tillDate) <= 0;
	}
}