package com.parser.utils;

public class Constants {

    /**
     * Directory for all files split from accesslog
     */
    public final static String FILE_SPLIT_DIRECTORY = System.getProperty("user.dir") + "/staging";

    public final static int NUMBER_OF_PROCESSORS = Runtime.getRuntime().availableProcessors();
}
