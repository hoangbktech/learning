package com.parser.dto;

public enum Duration {
	HOURLY,
	DAILY
}