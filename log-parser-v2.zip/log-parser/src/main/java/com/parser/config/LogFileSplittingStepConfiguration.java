package com.parser.config;

import com.parser.utils.Constants;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.step.tasklet.SystemCommandTasklet;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.File;

@Configuration
public class LogFileSplittingStepConfiguration {

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    // Step 1 Beans
    @Bean
    @StepScope
    public SystemCommandTasklet fileSplittingTasklet(@Value("#{jobParameters['fileName']}") String inputFile) throws Exception {
        File splitDescFolder = new File(Constants.FILE_SPLIT_DIRECTORY);
        if (!splitDescFolder.exists())
            splitDescFolder.mkdirs();

        SystemCommandTasklet tasklet = new SystemCommandTasklet();

        tasklet.setCommand("split -a 5 -l 10000 " + inputFile);
        tasklet.setTimeout(60000l);
        tasklet.setWorkingDirectory(Constants.FILE_SPLIT_DIRECTORY);
        tasklet.afterPropertiesSet();

        return tasklet;
    }

    @Bean("fileSplittingStep")
    public Step fileSplittingStep(Tasklet fileSplittingTasklet) throws Exception {
        return stepBuilderFactory.get("fileSplittingStep")
                .tasklet(fileSplittingTasklet)
                .build();
    }
}
