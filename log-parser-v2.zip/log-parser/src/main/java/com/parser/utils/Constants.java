package com.parser.utils;

public class Constants {

    /**
     * Directory for all files split from accesslog
     */
    public final static String FILE_SPLIT_DIRECTORY = System.getProperty("user.dir") + "/staging";
}
