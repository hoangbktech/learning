package com.parser.listener;

import static org.springframework.batch.core.BatchStatus.*;

import com.parser.utils.Constants;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

import java.io.File;

@Slf4j
@Component
public class JobCompletionListener extends JobExecutionListenerSupport {

	private long startTime;

	@Override
	public void beforeJob(JobExecution jobExecution) {
		startTime = System.currentTimeMillis();
	}


	@Override
	public void afterJob(JobExecution jobExecution) {
		if (COMPLETED == jobExecution.getStatus()) {
			log.info("!!! JOB FINISHED : {}ms!", System.currentTimeMillis() - startTime);
			File splitDescFolder = new File(Constants.FILE_SPLIT_DIRECTORY);
			if (splitDescFolder.exists()) {
				boolean success = splitDescFolder.delete();
				log.info("Remove all files generated during splitting step {}", success ? "successfully" : "unsuccessfully");
			}
		} else if (FAILED == jobExecution.getStatus()) {
			log.error("!!! JOB FAILED!");
		}
	}
}